safari.extension.dispatchMessage("getAllUrl", {"url" : window.location.href});
document.addEventListener("DOMContentLoaded", function(event) {
//    safari.extension.dispatchMessage("getTabUrl");
});
safari.self.addEventListener("message", handleMessage);
function handleMessage(event) {
    if (event.name == "getCookies") {
        var token = getCookie('qs_access_token');
        safari.extension.dispatchMessage("tokenReceived", {"token" : token});
    } else if (event.name == "onMerchantDetected") {
        try {
            var request = event.message;
            if (request.action === 'sho-hide') {
                let app1 = document.getElementById("sho-main")
                if (app1) app1.remove()
            }
            if (request.action === 'sho-show') {
                const fontUrl = safari.extension.baseURI + 'assets/Ciutadella-Regular.woff'
                const styleNode = document.createElement('style')
                styleNode.type = 'text/css'
                styleNode.textContent = `@font-face { font-family: Ciutadella-Regular; src: url('${fontUrl}'); }`
                document.head.appendChild(styleNode)
                IncludeStyle();
                IncludeScriptFile();
                let app = document.getElementById("sho-main")
                if (app) app.remove()
                    app = document.createElement('div')
                    app.id = "sho-main"
                    app.style.width = '260px'
                    app.style.position = 'fixed'
                    app.style.right = '10px'
                    app.style.top = '10px'
                    app.style.zIndex = '2147483647'
                    const lastIndex = document.firstElementChild.children.length
                    const lastNode = document.firstElementChild.children[lastIndex - 1]
                    if (lastNode.nodeName === 'DIV') {
                        lastNode.appendChild(app)
                    } else {
                        document.firstElementChild.appendChild(app)
                    }
                CreatePopup(request.data);
                app.style.display = "block";
            }
        } catch (e) {
            console.log(e.message);
        }
    } else if (event.name == "GoogleContent") {
        injectShoInGoogle(event.message);
    }
}

var injectShoInGoogle = async (data) => {
    const merchantData = data.merchantData;
    const merchantUrlmap = data.merchantData.merchantsUrlmap;
    const results = document.getElementsByClassName('r')
    for (let r of results) {
        if (r.nodeName === 'DIV') {
            const result = r.firstChild
            const url = result.href
            if (url) {
                const matchedMerchantId = await getMerchantIdForUrl(url, merchantUrlmap)
                const currentMerchant = merchantData[matchedMerchantId]
                const showMerchant = currentMerchant && currentMerchant.rebate && currentMerchant.toolbar_permitted && currentMerchant.isVisible
                if (showMerchant) {
                    if (!result['sho-banner-rendered']) {
                        result.prepend(renderHTML(currentMerchant.rebate.rebate_user))
                    }
                    result['sho-banner-rendered'] = 'true'
                }
            }
        }
    }
}
var getMerchantIdForUrl = async (url, data) => {
    if (!url) return undefined
        const endOfDomain = url.indexOf('/', 8)
        const hostUrl = url.substring(0, endOfDomain === -1 ? url.length : endOfDomain)
        const merchantMapping = (data)[hostUrl]
        if (merchantMapping) {
            if (merchantMapping.startsWith) {
                return url.startsWith(merchantMapping.startsWith) ? merchantMapping.merchantId : undefined
            } else {
                return merchantMapping.merchantId
            }
        }
    return undefined
}

var renderHTML = (points) => {
    const our = document.createElement('div')
    our.id = 'sho-search-result'
    our.style.marginBottom = '5px'
    our.style.display = 'flex'
    our.style.alignItems = 'center'
    our.style.color = '#e40000'
    our.style.fontSize = '16px'
    our.style.fontFamily = '"Ciutadella-Regular", Helvetica'
    const img = document.createElement('img')
    const text = document.createElement('span')
    img.style.marginRight = '5px'
    img.style.width = '24px'
    img.style.height = '24px'
    img.src = safari.extension.baseURI + "assets/icons/offer_available/offer_available_24x24.png"
    text.textContent = `Earn ${points} Qantas Points per $1 spent via Qantas Shopping`
    our.append(img, text)
    return our
}

function getCookie(cname) {
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') c = c.substring(1);
        if (c.indexOf(name) != -1) return c.substring(name.length, c.length);
    }
    return "";
}

function IncludeStyle() {
    var link = document.createElement("link");
    link.setAttribute("rel", "stylesheet");
    link.setAttribute("type", "text/css");
    link.setAttribute("href", safari.extension.baseURI + "styles/main.css");
    document.getElementsByTagName("head")[0].appendChild(link);
}

function IncludeScriptFile() {
    var script = document.createElement('script');
    script.type = "text/javascript";
    script.src = safari.extension.baseURI + "Scripts/ShoScript.js";
    document.getElementsByTagName('head')[0].appendChild(script);
}

function CreatePopup(data) {
    var currentmerchant = data.merchantData;
    var token = data.token;
    var points = currentmerchant.rebate.rebate_user;
    var details = currentmerchant.details[0].info_special_terms.toString();
    var divmain = document.createElement('div');
    divmain.classList.add('q-plugin');
    var divheader = document.createElement('div');
    divheader.classList.add("sho-header");
//    var Headerimg = '<svg xmlns="http://www.w3.org/2000/svg" width="131" height="26" viewBox="0 0 131 30"><defs><linearGradient id="a" x1="21.927%" x2="121.442%" y1="-2.703%" y2="91.124%"><stop offset="0%" stop-color="#FFF"></stop><stop offset="49.724%" stop-color="#F3F3F3"></stop><stop offset="61.582%" stop-color="#EDEDED"></stop><stop offset="72.376%" stop-color="#DDD"></stop><stop offset="100%" stop-color="#ACACAC"></stop></linearGradient><linearGradient id="b" x1="24.466%" x2="119.958%" y1="-.309%" y2="89.725%"><stop offset="0%" stop-color="#FFF"></stop><stop offset="11.488%" stop-color="#F2F2F2"></stop><stop offset="25.399%" stop-color="#E2E2E2"></stop><stop offset="42.849%" stop-color="#E5E5E5"></stop><stop offset="54.676%" stop-color="#BFC0BF"></stop><stop offset="55.97%" stop-color="#BBBCBB"></stop><stop offset="57.264%" stop-color="#BABBBA"></stop><stop offset="66.322%" stop-color="#B3B3B3"></stop><stop offset="74.067%" stop-color="#B4B4B4"></stop><stop offset="100%" stop-color="#B1B1B1"></stop></linearGradient><radialGradient id="c" cx="22.556%" cy="3.061%" r="100.188%" fx="22.556%" fy="3.061%" gradientTransform="matrix(.36008 .66109 -.4327 1.02333 .158 -.15)"><stop offset="0%" stop-color="#A7A7A7"></stop><stop offset="23.106%" stop-color="#D0D0D0"></stop><stop offset="45.608%" stop-color="#D9D9D9"></stop><stop offset="70.924%" stop-color="#E5E5E5"></stop><stop offset="70.924%" stop-color="#F1F1F1"></stop><stop offset="100%" stop-color="#FFF"></stop></radialGradient><linearGradient id="d" x1="29.663%" x2="70.337%" y1="4.323%" y2="95.677%"><stop offset="0%" stop-color="#FF0401"></stop><stop offset="12.719%" stop-color="#FF0401"></stop><stop offset="23.246%" stop-color="#FF0401"></stop><stop offset="35.965%" stop-color="#FE0401"></stop><stop offset="51.316%" stop-color="#FB0401"></stop><stop offset="83.333%" stop-color="#DE0301"></stop><stop offset="88.596%" stop-color="#DE0301"></stop><stop offset="95.175%" stop-color="#DE0301"></stop><stop offset="100%" stop-color="#DE0301"></stop></linearGradient></defs><g fill="none" fill-rule="evenodd"><path fill="#323232" d="M68.333 3.645V7.5c0 1.305-.615 2.295-1.59 2.79l1.53 2.205h-1.395l-1.275-1.89c-.165.03-.33.045-.51.045-1.92 0-3.24-1.215-3.24-3.15V3.645c0-1.935 1.26-3.15 3.24-3.15 1.92 0 3.24 1.215 3.24 3.15zm-5.34-.03V7.53c0 1.2.765 2.085 2.1 2.085s2.085-.885 2.085-2.085V3.615c0-1.2-.75-2.085-2.085-2.085s-2.1.885-2.1 2.085zm8.915 6.885h-1.125l3.15-9.855h1.155l3.18 9.855h-1.185l-.72-2.265h-3.75l-.705 2.265zm2.565-8.31l-1.56 5.055h3.165L74.473 2.19zM87.408.645V10.5h-.945l-4.275-7.62v7.62h-1.065V.645h1.02l4.2 7.5v-7.5h1.065zm2.78 1.035V.645h6.33V1.68h-2.595v8.82h-1.14V1.68h-2.595zm8.63 8.82h-1.125l3.15-9.855h1.155l3.18 9.855h-1.185l-.72-2.265h-3.75l-.705 2.265zm2.565-8.31l-1.56 5.055h3.165l-1.605-5.055zm12.215 1.26h-1.11v-.24c0-.99-.705-1.755-1.935-1.755-1.215 0-1.905.615-1.905 1.485 0 .69.48 1.185 1.125 1.44l1.62.66c1.125.45 2.385 1.05 2.385 2.745 0 1.74-1.305 2.865-3.21 2.865s-3.225-1.065-3.225-2.775v-.24h1.125v.3c0 1.005.765 1.74 2.085 1.74 1.335 0 2.1-.75 2.1-1.755 0-1.065-.765-1.485-1.68-1.845l-1.395-.57c-1.11-.435-2.025-1.155-2.025-2.475 0-1.485 1.2-2.535 3-2.535s3.045 1.065 3.045 2.775v.18zm-45.76 17.073h-1.11v-.24c0-.99-.705-1.755-1.935-1.755-1.215 0-1.905.615-1.905 1.485 0 .69.48 1.185 1.125 1.44l1.62.66c1.125.45 2.385 1.05 2.385 2.745 0 1.74-1.305 2.865-3.21 2.865s-3.225-1.065-3.225-2.775v-.24h1.125v.3c0 1.005.765 1.74 2.085 1.74 1.335 0 2.1-.75 2.1-1.755 0-1.065-.765-1.485-1.68-1.845l-1.395-.57c-1.11-.435-2.025-1.155-2.025-2.475 0-1.485 1.2-2.535 3-2.535s3.045 1.065 3.045 2.775v.18zm9.74-2.805v9.855h-1.155v-4.515h-4.035v4.515h-1.14v-9.855h1.14v4.305h4.035v-4.305h1.155zm9.95 3v3.855c0 1.935-1.32 3.15-3.24 3.15-1.92 0-3.24-1.215-3.24-3.15v-3.855c0-1.935 1.26-3.15 3.24-3.15 1.92 0 3.24 1.215 3.24 3.15zm-5.34-.03v3.915c0 1.2.765 2.085 2.1 2.085s2.085-.885 2.085-2.085v-3.915c0-1.2-.75-2.085-2.085-2.085s-2.1.885-2.1 2.085zm8.81 6.885v-9.855h3.015c1.935 0 3.33 1.23 3.33 3.135 0 1.935-1.395 3.195-3.33 3.195h-1.875v3.525h-1.14zm2.94-8.85h-1.8v4.32h1.8c1.38 0 2.235-.87 2.235-2.175 0-1.305-.855-2.145-2.235-2.145zm6.47 8.85v-9.855h3.015c1.935 0 3.33 1.23 3.33 3.135 0 1.935-1.395 3.195-3.33 3.195h-1.875v3.525h-1.14zm2.94-8.85h-1.8v4.32h1.8c1.38 0 2.235-.87 2.235-2.175 0-1.305-.855-2.145-2.235-2.145zm7.61-1.005v9.855h-1.14v-9.855h1.14zm10.025 0v9.855h-.945l-4.275-7.62v7.62h-1.065v-9.855h1.02l4.2 7.5v-7.5h1.065zm6.965 5.97v-.93h2.91v1.98c0 1.845-1.275 2.985-3.165 2.985-1.905 0-3.24-1.215-3.24-3.15v-3.855c0-1.935 1.29-3.15 3.24-3.15 1.89 0 3.165 1.08 3.165 2.835v.225h-1.095v-.255c0-1.02-.735-1.77-2.07-1.77s-2.1.885-2.1 2.085v3.915c0 1.2.765 2.085 2.1 2.085 1.35 0 2.1-.81 2.1-1.92v-1.08h-1.845z"></path><path stroke="#979797" stroke-linecap="square" stroke-width="1.067" d="M50.016 4.712v21.341" opacity=".7"></path><g><path fill="#FFF" d="M2.56 5.39c.759 1.289 1.837 2.326 3.003 3.242 3.935 3.091 9.247 4.876 9.986 11.639.039.36.307.692.668.746 1.78.279 3.58.708 5.296 1.3a29.527 29.527 0 0 1 5.502 2.538 29.129 29.129 0 0 1 3.365 2.306l.076.05c.026.023.06.035.094.035a.148.148 0 1 0 .11-.253 30.444 30.444 0 0 0-5.935-4.779 30.235 30.235 0 0 0-3.96-2.046c-.193-.084-.99-.403-1.193-.485-.206-.084-.62-.248-.62-.248-.091-.037-.188-.072-.28-.12a1.71 1.71 0 0 1-.859-1.079 1.458 1.458 0 0 1-.05-.417c.005-.216.045-.413.128-.588.105-.222.259-.418.463-.586a3.57 3.57 0 0 1 .969-.542 9.394 9.394 0 0 1 1.296-.389c.519-.12 1.076-.228 1.586-.322a18.308 18.308 0 0 0 1.417-.31c.21-.056.388-.12.547-.188.26-.112.452-.242.538-.412l.12-.235c-.259-.22-.535-.423-.812-.619a11.864 11.864 0 0 0-2.376-1.289c-.43-.175-.866-.327-1.316-.45-.002.028-.01.063-.01.09 0 .064.01.135.02.197.017.106.061.207.103.304.05.114.09.223.172.325.37.6-.41 1.556-1.537.524l-.118-.105a23.851 23.851 0 0 0-.664-.578 22.318 22.318 0 0 0-3.468-2.426 24.02 24.02 0 0 0-.969-.522c-1.374-.695-2.673-1.167-3.887-1.577C5.957 6.767 2.847 6.15.833.95L2.56 5.39z"></path><path fill="url(#a)" d="M2.173 5.481c3.313 5.629 12.012 6.223 12.954 14.974-.947-11.169-5.88-9.499-11.18-14.583C2.576 4.906 1.42 3.49.493 1.096L2.173 5.48z" transform="translate(.473)"></path><path fill="url(#b)" d="M29.7 27.164c-4.854-5.236-10.115-6.217-12.06-6.217a3.936 3.936 0 0 0-1.256.167c5.23 1 9.178 2.74 13.316 6.05z" transform="translate(.473)"></path><path fill="url(#c)" d="M19.58 13.619c.562.095 1.549.32 2.246.174a2.096 2.096 0 0 1-1.784-1.03.516.516 0 0 1-.007.52.522.522 0 0 1-.455.253v.083z" transform="translate(.473)"></path><path fill="url(#d)" d="M41.691 29.258l-.074.033H11.304L2.07 5.368c3.33 5.615 12.07 6.208 13.02 14.939.04.359.319.647.68.703a30.268 30.268 0 0 1 14.21 6.2c.027.023.057.033.2-.008a.149.149 0 0 0 .004-.212 30.256 30.256 0 0 0-10.606-7.118l-1.233-.49a1.664 1.664 0 0 1-1.054-1.587c.069-2.608 6.318-2.077 6.951-3.331l.11-.216a11.735 11.735 0 0 0-4.5-2.358c-.015.062-.056.366.287.918.372.598-.408 1.55-1.544.523l-.095-.087C10.056 5.607 3.725 9.567.38.994L0 .01h5.1c4.594 0 9 1.906 12.248 5.112L41.69 29.258z" transform="translate(.473)"></path></g></g></svg>';
//    divheader.innerHTML = Headerimg;
    
    
    const img = document.createElement('img')
    img.style.height = '26px'
    img.style.width = '131px'
    img.src = safari.extension.baseURI + "assets/logo.png"
    divheader.appendChild(img);
    var closebutton = document.createElement('button');
    closebutton.id = 'shoclose';
    closebutton.name = currentmerchant.merchantId;
    closebutton.classList.add("sho-close-button");
    var closeimg = '<svg xmlns="http://www.w3.org/2000/svg" id="sho_q_close" name=' + currentmerchant.merchantId + '  width="17" height="17" viewBox="0 0 17 17"><path fill="#282B26" fill-rule="evenodd" d="M15.288 0L8.5 6.79 1.712 0 0 1.712 6.788 8.5 0 15.288 1.712 17 8.5 10.212 15.288 17 17 15.288 10.212 8.5 17 1.712z"></path></svg>';
    closebutton.innerHTML = closeimg;
    closebutton.setAttribute('onclick', 'CloseShopopup();');
    divheader.appendChild(closebutton);
    divmain.appendChild(divheader);
    var divcontent = document.createElement('div');
    divcontent.classList.add('sho-main');
    if (token.isValidToken && currentmerchant.isTracking) {
        var p = document.createElement('p');
        p.classList.add("sho-title");
        p.innerHTML = "Earn <strong>" + points + " points</strong> per $1 spent";
        divcontent.appendChild(p);
        var button = CreateButton("OfferActivated", currentmerchant.merchantId);
        divcontent.appendChild(button);
    } else if (token.isValidToken && currentmerchant) {
        var p = document.createElement('p');
        p.classList.add("sho-title");
        p.innerHTML = "Earn <strong>" + points + " points</strong> per $1 spent";
        divcontent.appendChild(p);
        var button = CreateButton("ActivateOfferButton", currentmerchant.merchantId);
        divcontent.appendChild(button);
    } else if (!token.isValidToken && currentmerchant) {
        var p = document.createElement('p');
        p.classList.add("sho-title");
        p.innerHTML = "Earn <strong>" + points + " points</strong> per $1 spent";
        divcontent.appendChild(p);
        var button = CreateButton("LoginMerchant", currentmerchant.merchantId);
        divcontent.appendChild(button);
    }
    divcontent.appendChild(CreateTermsandconditions(details));
    divmain.appendChild(divcontent);
    var shomain = document.getElementById("sho-main");
    shomain.appendChild(divmain);
}

function CreateButton(ButtonName, merchantId) {
    var buttonelement = document.createElement('button');
    switch (ButtonName) {
        case "ActivateOfferButton":
            buttonelement.classList.add('sho-activate');
            buttonelement.classList.add('sho-button');
            buttonelement.textContent = 'EARN QANTAS POINTS';
            buttonelement.setAttribute("style", "color:#fff !important")
            var url = "https://shopping.qantas.com" + "/shop?id=" + merchantId + "&fp=true";
            buttonelement.setAttribute("onclick", 'OpenTab(\'' + url + '\');');
            break;
        case "OfferActivated":
            buttonelement.classList.add('sho-success');
            buttonelement.classList.add('sho-button');
            buttonelement.setAttribute("style", "color:#fff !important")
            var svg = '<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 14 14">';
            svg = svg + '<path fill="#FFF" fill-rule="nonzero" d="M7 0a7 7 0 1 0 0 14A7 7 0 0 0 7 0zm-.75 10.502L3 7.25l1.396-1.396 1.855 1.854L9.96 4l1.395 1.396-5.105 5.106z"></path></svg>'
            buttonelement.innerHTML = svg;
            var spant = document.createElement('span');
            spant.textContent = 'Tracking';
            buttonelement.appendChild(spant);
            break;
        case "TryAgainButton":
            buttonelement.classList.add('suboptimal');
            buttonelement.classList.add('sho-button');
            buttonelement.setAttribute("style", "color:#fff !important")
            buttonelement.textContent = 'TRY AGAIN LATER';
            break;
        case "LoginButton":
            buttonelement.classList.add('sho-activate');
            buttonelement.classList.add('sho-button');
            buttonelement.textContent = 'LOG IN TO EARN';
            var url = "https://shopping.qantas.com" + "/login/points-prompter";
            buttonelement.setAttribute("style", "color:#fff !important")
            buttonelement.setAttribute("onclick", 'OpenTab(\'' + url + '\');');
            break;
        case "LoginMerchant":
            buttonelement.classList.add('sho-activate');
            buttonelement.classList.add('sho-button');
            buttonelement.textContent = 'LOG IN TO EARN';
            buttonelement.setAttribute("style", "color:#fff !important")
            var url = "https://shopping.qantas.com" + "/login/" + merchantId + "?fp=true";
            buttonelement.setAttribute("onclick", 'OpenTab(\'' + url + '\');');
            break;
        default:
            break;
    }
    return buttonelement;
}

function CreateTermsandconditions(details) {
    var div = document.createElement('div');
    div.classList.add("sho-terms");
    var a = document.createElement('a');
    a.classList.add('sho-open-terms');
    a.innerHTML = "Terms & conditions";
    a.setAttribute('onclick', "ToggleTerms();");
    var shotermsdetails = document.createElement('div');
    shotermsdetails.id = "sho-term-details";
    shotermsdetails.classList.add('sho-terms-details');
    shotermsdetails.classList.add('sho-hidden');
    var p = document.createElement("p");
    p.classList.add("sho-terms-details-title");
    p.innerHTML = "<strong>Terms & Conditions</strong>";
    var aclose = document.createElement('a');
    aclose.classList.add("sho-tc-close");
    aclose.setAttribute('onclick', 'ToggleTerms();');
    aclose.innerHTML = "Close";
    p.appendChild(aclose);
    var pdetails = document.createElement('p');
    pdetails.classList.add('sho-terms-details-text');
    pdetails.textContent = details;
    shotermsdetails.appendChild(p);
    shotermsdetails.appendChild(pdetails);
    div.appendChild(a);
    div.appendChild(shotermsdetails);
    return div;
}

document.addEventListener('click', function(event) {
    var element = event.target.closest('button');
    if (element.id == 'shoclose')
        safari.extension.dispatchMessage("sho-notification-closed", {"data" : element.name});
    }, true);
